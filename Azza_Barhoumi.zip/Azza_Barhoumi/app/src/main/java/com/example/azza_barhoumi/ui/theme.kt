package com.example.azza_barhoumi.ui



import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable

@Composable
fun CountryGameTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        content = content
    )
}