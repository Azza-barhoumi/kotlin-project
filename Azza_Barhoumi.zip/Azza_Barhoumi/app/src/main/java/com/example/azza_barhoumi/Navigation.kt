package com.example.azza_barhoumi.ui

import android.content.Intent
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.azza_barhoumi.ui.screens.AnswerScreen
import com.example.azza_barhoumi.ui.screens.QuestionScreen
import com.example.azza_barhoumi.ui.screens.ScoreScreen
import com.example.azza_barhoumi.ui.viewmodel.GameViewModel

@Composable
fun azza_barhoumiNavigation() {
    val navController = rememberNavController()
    val viewModel: GameViewModel = viewModel()
    val context = LocalContext.current

    NavHost(
        navController = navController,
        startDestination = "question"
    ) {
        composable("question") {
            QuestionScreen(
                viewModel = viewModel,
                onAnswer = { answer ->
                    viewModel.checkAnswer(answer)
                    navController.navigate("answer")
                }
            )
        }
        composable("answer") {
            AnswerScreen(
                viewModel = viewModel,
                onNextQuestion = {
                    viewModel.moveToNextQuestion()
                    navController.popBackStack()
                },
                onFinishGame = {
                    navController.navigate("score")
                }
            )
        }
        composable("score") {
            ScoreScreen(
                viewModel = viewModel,
                onPlayAgain = {
                    viewModel.resetGame()
                    navController.popBackStack("question", inclusive = false)
                }
            )
        }
    }
}