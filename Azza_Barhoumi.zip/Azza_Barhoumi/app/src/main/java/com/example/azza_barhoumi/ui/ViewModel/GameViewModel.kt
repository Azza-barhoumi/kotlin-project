package com.example.azza_barhoumi.ui.ViewModel




import androidx.lifecycle.ViewModel
import com.example.azza_barhoumi.data.Country
import com.example.azza_barhoumi.data.CountryRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class GameViewModel(
    mockContext: CountryRepository,
    private val repository: CountryRepository = CountryRepository()
) : ViewModel() {
    private val allCountries = repository.getCountries()
    private val gameCountries = allCountries.take(10) // Use only 10 out of 15
    private var currentQuestionIndex = 0
    private val maxQuestions = 10

    private val _uiState = MutableStateFlow(GameUiState())
    val uiState: StateFlow<GameUiState> = _uiState.asStateFlow()

    init {
        startNewGame()
    }

    private fun startNewGame() {
        currentQuestionIndex = 0
        _uiState.value = GameUiState(
            currentCountry = gameCountries[currentQuestionIndex],
            score = 0,
            questionCount = 1,
            gameOver = false,
            showAnswer = false
        )
    }

    fun checkAnswer(userAnswer: String) {
        val isCorrect = userAnswer.equals(_uiState.value.currentCountry.name, ignoreCase = true)
        val newScore = if (isCorrect) _uiState.value.score + 1 else _uiState.value.score

        _uiState.value = _uiState.value.copy(
            isAnswerCorrect = isCorrect,
            score = newScore,
            showAnswer = isCorrect
        )
    }

    fun moveToNextQuestion() {
        currentQuestionIndex++
        if (currentQuestionIndex < maxQuestions) {
            _uiState.value = GameUiState(
                currentCountry = gameCountries[currentQuestionIndex],
                score = _uiState.value.score,
                questionCount = _uiState.value.questionCount + 1,
                showAnswer = false,
                gameOver = false
            )
        } else {
            _uiState.value = _uiState.value.copy(gameOver = true)
        }
    }

    fun resetGame() {
        startNewGame()
    }
}

data class GameUiState(
    val currentCountry: Country = Country("", 0, "", "", 0, ""),
    val score: Int = 0,
    val questionCount: Int = 1,
    val isAnswerCorrect: Boolean = false,
    val showAnswer: Boolean = false,
    val gameOver: Boolean = false
)