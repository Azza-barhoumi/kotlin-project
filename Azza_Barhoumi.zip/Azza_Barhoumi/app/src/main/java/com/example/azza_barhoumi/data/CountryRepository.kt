package com.example.azza_barhoumi.data

import com.example.azza_barhoumi.R
import com.example.azza_barhoumi.data.Country





open class CountryRepository {
    open fun getCountries(): List<Country> {
        return listOf(
            Country(
                "France", R.drawable.flag_france, "Paris", "Eiffel Tower",
                R.drawable.eiffel_tour, "The Eiffel Tower is an iron lattice tower in Paris, named after engineer Gustave Eiffel. Built in 1889, it's one of the most recognizable structures in the world."
            ),
            Country(
                "Japan", R.drawable.japan_flag, "Tokyo", "Mount Fuji",
                R.drawable.mount_fuji, "Mount Fuji is Japan's tallest mountain at 3,776 meters. This active volcano is considered sacred and has been a pilgrimage site for centuries."
            ),
            Country(
                "Italy", R.drawable.flag_italy, "Rome", "Colosseum",
                R.drawable.colosseum, "The Colosseum is an oval amphitheater in Rome, built in 70-80 AD. It was used for gladiatorial contests and public spectacles."
            ),
            Country(
                "Egypt", R.drawable.egypt_flag, "Cairo", "Great Pyramids",
                R.drawable.pyramids, "The Great Pyramid of Giza is the oldest of the Seven Wonders of the Ancient World, and the only one to remain largely intact."
            ),
            Country(
                "Brazil", R.drawable.flag_brazil, "Brasília", "Christ the Redeemer",
                R.drawable.christ_redeemer, "Christ the Redeemer is an Art Deco statue of Jesus Christ in Rio de Janeiro, standing 30 meters tall on top of Corcovado mountain."
            ),
            Country(
                "India", R.drawable.flag_india, "New Delhi", "Taj Mahal",
                R.drawable.taj_mahal, "The Taj Mahal is an ivory-white marble mausoleum in Agra, built by Mughal emperor Shah Jahan in memory of his wife Mumtaz Mahal."
            ),
            Country(
                "China", R.drawable.flag_china, "Beijing", "Great Wall",
                R.drawable.great_wall, "The Great Wall of China is a series of fortifications made of stone, brick, tamped earth, and other materials built along an east-to-west line."
            ),
            Country(
                "United States", R.drawable.flag_usa, "Washington D.C.", "Statue of Liberty",
                R.drawable.statue_of_liberty, "The Statue of Liberty is a colossal neoclassical sculpture on Liberty Island in New York Harbor, a gift from France."
            ),
            Country(
                "Australia", R.drawable.flag_australia, "Canberra", "Sydney Opera House",
                R.drawable.sydney_opera, "The Sydney Opera House is a multi-venue performing arts centre known for its distinctive shell-like sail design."
            ),
            Country(
                "United Kingdom", R.drawable.flag_uk, "London", "Big Ben",
                R.drawable.big_ben, "Big Ben is the nickname for the Great Bell of the clock at the north end of the Palace of Westminster in London."
            ),
            Country(
                "Germany", R.drawable.flag_germany, "Berlin", "Brandenburg Gate",
                R.drawable.brandenburg_gate, "The Brandenburg Gate is an 18th-century neoclassical monument in Berlin, built on the orders of Prussian king Frederick William II."
            ),
            Country(
                "Spain", R.drawable.flag_spain, "Madrid", "Sagrada Familia",
                R.drawable.sagrada_familia, "The Basílica de la Sagrada Família is a large unfinished Roman Catholic church in Barcelona, designed by architect Antoni Gaudí."
            ),
            Country(
                "Russia", R.drawable.flag_russia, "Moscow", "Saint Basil's Cathedral",
                R.drawable.saint_basil, "The Cathedral of Vasily the Blessed is a church in Red Square in Moscow, known for its colorful onion domes."
            ),
            Country(
                "Canada", R.drawable.flag_canada, "Ottawa", "CN Tower",
                R.drawable.cn_tower, "The CN Tower is a 553.3 m-high concrete communications and observation tower in Toronto, completed in 1976."
            ),
            Country(
                "Mexico", R.drawable.flag_mexico, "Mexico City", "Chichen Itza",
                R.drawable.chichen_itza, "Chichen Itza was a large pre-Columbian city built by the Maya people of the Terminal Classic period."
            )
        ).shuffled()
    }
}