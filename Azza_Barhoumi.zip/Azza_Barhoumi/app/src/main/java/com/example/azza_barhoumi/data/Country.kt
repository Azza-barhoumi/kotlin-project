package com.example.azza_barhoumi.data

data class Country(
    val name: String,
    val flagResId: Int,
    val capital: String,
    val feature: String,
    val featureImageResId: Int,
    val description: String
)
