package com.example.azza_barhoumi.viewmodel

import com.example.azza_barhoumi.data.Country
import com.example.azza_barhoumi.data.CountryRepository
import com.example.azza_barhoumi.ui.ViewModel.GameViewModel
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class GameViewModelTest {
    private lateinit var viewModel: GameViewModel
    private val testCountries = listOf(
        Country("France", 1, "Paris", "Eiffel Tower", 1, "Description")
    )

    @Before
    fun setup() {
        // Create a simple fake repository
        val fakeRepository = object : CountryRepository {
            override fun getCountries(): List<Country> = testCountries
        }

        viewModel = GameViewModel(fakeRepository)
    }

    @Test
    fun `correct answer increases score`() {
        // Initial score should be 0
        assertEquals(0, viewModel.uiState.value.score)

        // Answer correctly
        viewModel.checkAnswer("France")

        // Score should now be 1
        assertEquals(1, viewModel.uiState.value.score)
        assertTrue(viewModel.uiState.value.isAnswerCorrect)
    }
}