package com.example.azza_barhoumi.ui.screens

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performTextInput
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class QuestionScreenTest {
    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun questionScreen_showsFlagQuestion() {
        // Launch the screen
        composeTestRule.setContent {
            QuestionScreen(
                viewModel = null, // Not needed for this simple test
                onAnswer = {}
            )
        }

        // Verify the question text appears
        composeTestRule.onNodeWithText("What country does this flag belong to?")
            .assertExists()
    }

    @Test
    fun canTypeCountryName() {
        composeTestRule.setContent {
            QuestionScreen(
                viewModel = null,
                onAnswer = {}
            )
        }

        // Type into the text field
        composeTestRule.onNodeWithText("Country name")
            .performTextInput("France")

        // Verify the text was entered
        composeTestRule.onNodeWithText("France")
            .assertExists()
    }
}